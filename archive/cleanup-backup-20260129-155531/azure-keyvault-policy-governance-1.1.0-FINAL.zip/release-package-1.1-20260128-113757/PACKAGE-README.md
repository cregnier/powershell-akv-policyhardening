# Azure Key Vault Policy Governance Framework - Release 1.1.0

**Release Date**: January 28, 2026  
**Package Version**: 1.1.0  
**Status**: Production Ready

---

## 🚀 Quick Start

1. **Review Prerequisites**:
   - Read documentation/DEPLOYMENT-PREREQUISITES.md
   - Ensure Azure PowerShell modules installed
   - Confirm Contributor role on target subscription

2. **Setup Infrastructure** (one-time):
   ```powershell
   .\scripts\Setup-AzureKeyVaultPolicyEnvironment.ps1
   ```

3. **Deploy First Scenario** (Audit mode - safe):
   ```powershell
   .\scripts\AzPolicyImplScript.ps1 `
       -ParameterFile .\parameters\PolicyParameters-Production.json `
       -PolicyMode Audit `
       -ScopeType Subscription `
       -SkipRBACCheck
   ```

4. **Check Compliance**:
   ```powershell
   .\scripts\AzPolicyImplScript.ps1 -CheckCompliance -TriggerScan
   ```

**For detailed instructions, see documentation/QUICKSTART.md**

---

## 📦 Package Contents

### Core Scripts (scripts/)
- **AzPolicyImplScript.ps1**: Main deployment, testing, compliance, exemption management
- **Setup-AzureKeyVaultPolicyEnvironment.ps1**: Infrastructure setup and cleanup

### Documentation (documentation/)
- **README.md**: Master index and overview ← START HERE
- **QUICKSTART.md**: Fast-track deployment guide
- **DEPLOYMENT-WORKFLOW-GUIDE.md**: Complete workflows for all 7 scenarios
- **DEPLOYMENT-PREREQUISITES.md**: Setup requirements
- **SCENARIO-COMMANDS-REFERENCE.md**: All validated commands
- **POLICY-COVERAGE-MATRIX.md**: 46 policies coverage analysis
- **CLEANUP-EVERYTHING-GUIDE.md**: Cleanup procedures
- **UNSUPPORTED-SCENARIOS.md**: HSM & integrated CA limitations
- **Comprehensive-Test-Plan.md**: Full testing strategy

### Parameter Files (parameters/)
- **PolicyParameters-DevTest.json**: Scenarios 1-3 (30 policies Audit)
- **PolicyParameters-DevTest-Full.json**: Scenario 4 (46 policies Audit)
- **PolicyParameters-DevTest-Full-Remediation.json**: DevTest auto-remediation
- **PolicyParameters-Production.json**: Scenario 5 (46 policies Audit)
- **PolicyParameters-Production-Deny.json**: Scenario 6 (34 policies Deny)
- **PolicyParameters-Production-Remediation.json**: Scenario 7 (Auto-remediation)

### Reference Data (reference-data/)
- **DefinitionListExport.csv**: 46 policy definitions
- **PolicyNameMapping.json**: Display name → ID mappings
- **PolicyImplementationConfig.json**: Runtime configuration

---

## 🎯 Deployment Scenarios

| Scenario | Parameter File | Policies | Mode | Use Case |
|----------|---------------|----------|------|----------|
| 1-3: DevTest | PolicyParameters-DevTest.json | 30 | Audit | Initial testing |
| 4: DevTest Full | PolicyParameters-DevTest-Full.json | 46 | Audit | Complete testing |
| 5: Production Audit | PolicyParameters-Production.json | 46 | Audit | **Production baseline** ⭐ |
| 6: Production Deny | PolicyParameters-Production-Deny.json | 34 | Deny | **Enforcement** ⭐ |
| 7: Auto-Remediation | PolicyParameters-Production-Remediation.json | 46 | 8 Enforce + 38 Audit | **Full automation** ⭐ |

**Recommended Path**: Start with Scenario 5 → Monitor 7 days → Enable Scenario 6 → Add Scenario 7

---

## ⚠️ Important Notes

### Unsupported in MSDN Subscriptions
- **Managed HSM policies** (8 policies): Requires HSM quota and ~\/hour cost
- **Integrated CA policy** (1 policy): Requires DigiCert/GlobalSign integration

**See documentation/UNSUPPORTED-SCENARIOS.md for enablement procedures**

### Policy Scope
- **Deployment scope**: SUBSCRIPTION-WIDE (affects ALL Key Vaults)
- **Not recommended**: Per-resource or per-RG scoping
- **Production strategy**: Subscription + exemptions

### Cleanup Procedures
- **Remove policies**: AzPolicyImplScript.ps1 -Rollback
- **Remove infrastructure**: Setup-AzureKeyVaultPolicyEnvironment.ps1 -CleanupFirst

**See documentation/CLEANUP-EVERYTHING-GUIDE.md for complete procedures**

---

## 💰 Value Proposition

**Projected Annual Savings**: \,000/year
- Security breach prevention: \,800/year
- Operational efficiency: \,200/year

**Operational Impact**:
- Manual configuration: 6 hours/vault
- Automated: 10-15 minutes
- **Time savings**: 90-95% reduction

---

## 📞 Support

### Common Issues
1. "Policy assignment failed" → Check RBAC permissions
2. "No remediation tasks" → Wait 75-90 minutes after deployment
3. "HSM policies failing" → Expected in MSDN (quota limitation)

### Getting Help
- Review documentation/DEPLOYMENT-WORKFLOW-GUIDE.md for troubleshooting
- Check documentation/Comprehensive-Test-Plan.md for expected results
- See documentation/UNSUPPORTED-SCENARIOS.md for known limitations

---

## 📄 License

MIT License - see LICENSE file for details

---

**START HERE**: Read documentation/README.md for complete overview
